var measured = require('measured-core')

module.exports = measured.createCollection();
